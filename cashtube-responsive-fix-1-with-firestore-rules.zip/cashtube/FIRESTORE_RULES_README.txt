CashTube Firestore Rules
========================

File: firestore.rules

Deployment:
1. Open Firebase Console -> project `crash-tube` -> Firestore Database -> Rules.
2. Replace the existing rules with the contents of firestore.rules.
3. Publish.

IMPORTANT SECURITY NOTES
- These rules expect Firebase Authentication users and Firestore user document IDs
  to match request.auth.uid.
- Admin access requires a trusted Firebase Admin SDK environment to set the
  custom claim `admin: true`. The `ADMIN_IDS` array in index.html is client-side
  and is NOT a secure authorization mechanism.
- The existing app updates coin balances/reward counters from browser JavaScript.
  The users rule currently allows a user to update their own user document for
  compatibility, so a malicious user could manipulate their balance. Before
  using real-value rewards or withdrawals, move coin/reward/balance changes to
  trusted Cloud Functions and restrict users/{uid} updates to safe profile fields.
- adWatches is readable by any signed-in user because the app queries a
  cross-user daily leaderboard. Do not store sensitive information in it.
- Test in Firebase Emulator / a test project before publishing to production.
